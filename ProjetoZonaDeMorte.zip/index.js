console.log("Bem-vindo a Styleterno.")

/*console.log vazio para dar espaço entre um codigo e outro no console */

console.log("")

var idadeUsuario=prompt("qual a sua idade?");

while (idadeUsuario<18){

  if(idadeUsuario>=18){
  }else {
    console.log("somente com um responsável");}

    var idadeUsuario=prompt("qual a sua idade?");
}

console.log("")

var tamanho=prompt("qual tamanho que voce veste?(P,M,G ou GG)")

switch(tamanho){
    case "P"&& "p":
  console.log("tamanho P adicionado as prioridades.")
  break;
    case "M"&&"m":
  console.log("tamanho M adicionado as prioridades.")
  break;
    case "G"&&"g":
    console.log("tamanho G adicionado as prioridades.")
  break;
   case "GG"&&"gg":
    console.log("tamanho GG adicionado as prioridades.")
  break;
  default:
  console.log("Nenhuma prioridade de tamanho foi adicionada.")
}

console.log("");


var modeloterno=prompt("Temos esses modelos no estoque que cumpre os requisitos de tamanho informado por você: Jordhan Slim fit(1),Slim corte italiano(2),Slim fit oxford(3) e o padrão, que será adcionado caso não seja escolhido nenhuma das opções anteriores. Qual modelo você deseja?1,2 ou 3?");

switch(modeloterno){
    case "1":
  console.log("Modelo Jordhan Slim fit adcionado ao carrinho.");
  break;
    case "2":
  console.log("Modelo Slim corte italiano adcionado ao carrinho.");
  break;
    case "3":
    console.log("Modelo Slim fit oxford adcionado ao carrinho.");
  break;
  default:
  console.log("Modelo padrão adcionado.");
}

console.log("");

var corterno=prompt("Temos as cores: Azul,Vinho,Cinza,Branco ou o padrão(preto) que será adcionado caso não seja escolhido nenuma das anteriores. Qual cor você escolhe?")

switch(corterno){
    case "Azul" && "azul":
  console.log("Azul foi adcionada.")
  break;
    case "Vinho" && "vinho":
  console.log("Vinho foi adcionada.")
  break;
    case "Cinza" && "cinza":
    console.log("Cinza foi adcionada.")
  break;
  case "Branco" && "branco" :
    console.log("Branco foi adcionada.")
  break;
  default:
  console.log("cor padrão(preta) foi adcionada.")
}

console.log("");

do{
  var cartao=prompt("Modo de pagar vai ser cartão ou dinheiro?")
}while(cartao != "cartão" && cartao != "dinheiro");



  if(cartao.toLowerCase()=="cartão"){
  console.log("aguarde");
  console.log("");
  
    do{
      var debit=prompt("débito ou crédito?");
    }while(debit != "débito" && debit != "crédito");
    console.log("");

    var numerocartao=prompt("digite o numero do cartão");
    console.log("");

    var numerocartao=prompt("digite o nome do titular com está no cartão");
    console.log("");

    var numerocartao=prompt("digite a data de vencimento");
    console.log("");

    var numerocartao=prompt("digite o CVV do cartão(3 últimos dígitos)");
    console.log("");

    for( let i = 1;i < 4; i++){
    console.log("processando");
    }
       console.log("transação concluída");

  }else{ 
      console.log("boleto pronto, assim que o boleto for pago o pedido será enviado.");
    }
console.log("");

console.log("Obrigado por comprar na styleterno, volte sempre.");






